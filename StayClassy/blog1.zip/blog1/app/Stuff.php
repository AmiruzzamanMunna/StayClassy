<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stuff extends Model
{
    private $table="tbl_admin";
    public $timestamps=false;
}
