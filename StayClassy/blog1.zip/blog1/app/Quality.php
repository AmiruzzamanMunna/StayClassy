<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quality extends Model
{
    protected $table="tbl_quality";
     public $timestamps = false;
}
