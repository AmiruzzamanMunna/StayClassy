<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeftImage extends Model
{
    protected $table="tbl_left_image";
    public $timestamps=false;
}
