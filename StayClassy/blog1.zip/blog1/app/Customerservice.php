<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customerservice extends Model
{
    protected $table="tbl_customerservice";
    public $timestamps=false;
}
