<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carttbl extends Model
{
    protected $table = "tbl_cart";
    public $timestamps = false;
}
