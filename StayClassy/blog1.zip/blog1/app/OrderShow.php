<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderShow extends Model
{
    protected $table="view_order_final";
    public $timestamps=false;
}
