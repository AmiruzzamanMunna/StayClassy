<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Forgot_password extends Model
{
    protected $table = "tbl_forgot_pass";
    public $timestamps = false;
}
