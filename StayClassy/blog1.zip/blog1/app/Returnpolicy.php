<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Returnpolicy extends Model
{
    protected $table="tbl_returnpolicy";
    public $timestamps=false;
}
