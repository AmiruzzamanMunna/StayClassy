$(document).ready(function() {
	var $j = jQuery.noConflict();
	$j("#datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
});
$(document).ready(function() {
	var $j1 = jQuery.noConflict();
	$j1("#datepicker1").datepicker({ dateFormat: 'yy-mm-dd' });
});
