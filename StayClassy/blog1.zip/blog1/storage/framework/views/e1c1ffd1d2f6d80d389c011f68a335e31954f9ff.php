<?php $__env->startSection('title'); ?>
	Add Stuff
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script src="<?php echo e(asset('js')); ?>/validation/script3.js"></script>
	<script src="<?php echo e(asset('js')); ?>/jquery.validate.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8"><br><br>
		<form action="" method="POST" id="stuff-form">
			<?php echo e(csrf_field()); ?>

			<div class="card">
				<div class="card-header"><h2>New Member</h2></div>
				<div class="card-body">
						<div class="form-group row">
							<label class="col-md-4">Name:</label>
							<div class="col-md-8">
								<input type="text" class="form-control" name="name">
							</div>
							
						</div>
						<div class="form-group row">
							<label class="col-md-4">User Name:</label>
							<div class="col-md-8">
								<input type="text" class="form-control" name="username">
							</div>
							
						</div>
						<div class="form-group row">
							<label class="col-md-4">Phone:</label>
							<div class="col-md-8">
								<input type="text" class="form-control" name="phone">
							</div>
							
						</div>
						<div class="form-group row">
							<label class="col-md-4">Email:</label>
							<div class="col-md-8">
								<input type="email" class="form-control" name="email">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-4">Password</label>
							<div class="col-md-8">
								<input type="password" class="form-control" name="password">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-4">Confirm Password</label>
							<div class="col-md-8">
								<input type="password" class="form-control" name="confirm_password">
							</div>
						</div>
							<?php if($errors->any()): ?>
								<ul>
									<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo e($error); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							<?php endif; ?>
						<div class="row">
							<div class="col-md-9">
								<input type="reset" class="btn btn-danger" name="" value="Reset">
							</div>
						<div class="col-md-3">
							<input type="submit" class="btn btn-success" name="" value="Confirm">
						</div>
						<?php if(session('message')): ?>
							<div class="alert alert-success m-auto">
								<?php echo e(session('message')); ?>

							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>