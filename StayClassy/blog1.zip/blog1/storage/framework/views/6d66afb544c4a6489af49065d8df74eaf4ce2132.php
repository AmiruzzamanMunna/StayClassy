<?php $__env->startSection('title'); ?>
	Update Product Quantity
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style9.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-6 cat">
		<form method="post">
			<?php echo e(csrf_field()); ?>

			<div class="card crd">
					<h4 class="m-auto">Product Id:</h4>
				<div class="card-body">
					
					<div class="form-group row">
						<label class="col-md-6">Quantity:</label>
						<input type="text" name="Quantity" value="">
						<?php if($errors->any()): ?>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="m-auto"><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
					<div class=" form-group row">
						<div class="col-md-7 m-auto">
							<button type="submit" id="add-cart-button" class="btn btn-success col-md-8">Update Quantity</button>
						</div>
					</div>
				</div>
				<div class="card-footer">
					<?php if(session('message')): ?>
						<div class="alert alert-success m-auto">
							<?php echo e(session('message')); ?>

						</div>
					<?php endif; ?>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>