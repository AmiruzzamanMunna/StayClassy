<?php $__env->startSection('title'); ?>
	Contact
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8"><br><br><br>
		<form action="" method="post">
			<div class="card">
				<div class="card-header"><h2>Contact Information</h2></div>
				<div class="card-body">
					<div class="form-group row">
						<label class="col-md-4">Heading:</label>
						<input type="text" class="form-control col-md-6" name="chead">
					</div>
					<div class="form-group row">
						<label class="col-md-4">Contact Number:</label>
						<input type="number" class="form-control col-md-6" name="">
					</div>
					<div class="form-group row">
						<label class="col-md-4">Email:</label>
						<input type="email"class="form-control col-md-6">
					</div>
					<div class="row">
						<div class="col-md-3 ml-auto">
							<input type="submit" class="btn btn-success" name="" value="Save">
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>