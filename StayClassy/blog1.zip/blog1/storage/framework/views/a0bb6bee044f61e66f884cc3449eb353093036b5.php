<?php $__env->startSection('title'); ?>
	Transection
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<script type="text/javascript" src="<?php echo e(asset('js')); ?>/calender.js"></script>
	<script src="<?php echo e(asset('js')); ?>/calenderscript.js"></script>
	<script src="<?php echo e(asset('js')); ?>/script2.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8"><br><br>
		<div class="card">
			<div class="card-header"><h1>Transection History</h1></div>
			<div class="card-body">
				<table class="table table-bordered table-striped">
					<tr>
						<th>
							<form method="POST">
								<?php echo e(csrf_field()); ?>

								<div class="row m-auto">
									Date: <input type="text" id="datepicker" name="startdate" class="target">&nbsp;&nbsp;&nbsp;
									TO:<input type="text" id="datepicker1" name="enddate" class="target">&nbsp;&nbsp;&nbsp;
									<input type="submit" name="transaction" class="btn btn-danger" value="Submit">
								</div>	
							</form>
						</th>
						<th>Amount</th>
						<th>Role</th>
						</th>
					</tr>
						<?php $__empty_1 = true; $__currentLoopData = $transetions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transetion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($transetion->date); ?></td>
							<td><?php echo e($transetion->amount); ?></td>
							<td>
								<?php if($transetion->role == 0): ?>
									Invest
								<?php else: ?>
									Income
								<?php endif; ?>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<h1>Sorry No Transection Right now</h1>
						<?php endif; ?>
						<tr>
							<td>Total</td>
							<td>Invest=<?php echo e($invest); ?></td>
							<td>Income=<?php echo e($income); ?></td>
						</tr>
						<tr>
							<td></td>
							<td></td>
							<td>
								<?php if($profit == 0): ?>
								Loss = <?php echo e($loss); ?>

								<?php else: ?>
								Profit = <?php echo e($profit); ?>

								<?php endif; ?>
							</td>
						</tr>
				</table>
			</div>
			<div class="card-footer">
				<a href="<?php echo e(route('Pdf.report')); ?>" class="btn btn-success">Download</a>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>