<?php $__env->startSection('title'); ?>
	CheckOut Voucher
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style10.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8 m-auto">
		<div class="row">
			<div class="col-md-12">
				<form class="form" method="GET">
					<div class="card card1">
						<div class="card-header">Order Information</div>
							<div class="card-body">
								<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<div class="form-group row">
									<label class="col-md-6">Name:</label>
									<label class="col-md-6"><?php echo e($user->name); ?></label>
								</div>
								<div class="form-group row">
									<label class="col-md-6">Address:</label>
									<label class="col-md-6"><?php echo e($user->address); ?></label>
								</div>
								<div class="form-group row">
									<label class="col-md-6">E-Mail:</label>
									<label class="col-md-6"><?php echo e($user->email); ?></label>
									<?php break; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
								<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<div class="form-group row">
									<label class="col-md-6">Order No:</label>
									<label class="col-md-6"><?php echo e($user->id); ?></label>
								</div>
								<div class="form-group row">
									<label class="col-md-6">Product Code</label>
									<label class="col-md-6"><?php echo e($user->code); ?></label>
								</div>
								<div class="form-group row">
									<label class="col-md-6">Product Name</label>
									<label class="col-md-6"><?php echo e($user->product_name); ?></label>
								</div>
								<div class="form-group row">
									<label class="col-md-6">Subtotal Price</label>
									<label class="col-md-6"><?php echo e($user->totalprice); ?></label>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<?php endif; ?>
								<div class="form-group row">
									<label class="col-md-6">Total Price</label>
									<label class="col-md-6"><?php echo e($total); ?></label>
								</div>
								<div class="form-group row">
									<label class="col-md-6">Order Date</label>
									<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<label class="col-md-6"><?php echo e($user->date); ?></label>
									<?php break; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
							</div>
						<div class="card-footer">Thank You for your Order</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="row">
								<div class="col-md-6 ml-auto">
									<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<a href="<?php echo e(route('user.pdf',[$invoice->invoice_id])); ?>" class="btn btn-success col-md-8">Download</a>
									<?php break; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
						</div>
					</div>
				</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>