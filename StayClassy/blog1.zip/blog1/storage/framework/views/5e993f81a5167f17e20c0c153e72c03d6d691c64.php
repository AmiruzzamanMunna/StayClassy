<?php $__env->startSection('title'); ?>
	Admin DashBoard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
	<div class="col-md-8 m-auto"><br><br>
		<div class="row">
			<div class="col-md-12">
					<div class="card">
						<div class="card-header">Dash Board</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-3">
									<div class="card">
										<div class="card-header">Current Order</div>
										<div class="card-body">
											<img src="images/admin/order1.png">
											<div><h1><?php echo e($current_order); ?></h1></div>
										</div>
										<div class="card-footer">
											<a href="<?php echo e(route('order.index')); ?>">Details....</a>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="card">
										<div class="card-header">Total Order</div>
										<div class="card-body">
											<img id="cart1" src="images/admin/cart4.png">
											<div><h1><?php echo e($current_order); ?></h1></div>
										</div>
										<div class="card-footer">
											<a href="<?php echo e(route('order.index')); ?>">Details....</a>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="card">
										<div class="card-header">Total Delivered</div>
										<div class="card-body">
											<img src="images/admin/cart6.png">
											<div><h1><?php echo e($current_deliver); ?></h1></div>
										</div>
										<div class="card-footer">
											<a href="<?php echo e(route('order.delivered')); ?>">Details....</a>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="card">
										<div class="card-header">Total Returnded</div>
										<div class="card-body">
											<img src="images/admin/cart1.png">
											<div><h1><?php echo e($current_return); ?></h1></div>
										</div>
										<div class="card-footer">
											<a href="<?php echo e(route('order.returned')); ?>">Details....</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
			</div>
		</div><br><br>
		<div class="row">
			<dir class="col-md-12">
				<div class="card">
					<div class="card-header"><h2>Latest Order</h2></div>
					<div class="card-body">
						<table class="table table-bordered table-md table-striped">
							<tr>
								<th>Customer Name</th>
								<th>Mobile 1</th>
								<th>Address</th>
								<th>Order Date</th>
								<th>Status</th>
								<th>Price</th>
								<th>Details</th>
							</tr>
							<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($order->name); ?></td>
								<td><?php echo e($order->mobile1); ?></td>
								<td><?php echo e($order->address); ?></td>
								<td><?php echo e($order->order_date); ?></td>
								<td><?php echo e($order->status_name); ?></td>
								<td><?php echo e($order->totalprice); ?></td>
								<td><a href="<?php echo e(route('order.orderdetails',[$order->invoice_id])); ?>">Show</a></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</table>
					</div>
					<div class="card-footer">
						
						<div class="row">
							<dir class="col-md-12">
								<div class="row">
									<div class="col-md-2 m-auto">
										<?php echo e($orders->links()); ?>

									</div>
								</div>
							</dir>
						</div>
					</div>
				</div>
			</dir>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>