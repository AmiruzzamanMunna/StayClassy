<?php $__env->startSection('title'); ?>
	Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style3.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="container c1">
		<div class="row">
			<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
				<img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" class="rounded-circle rcc" alt="logo">
				<p><?php echo e($product->discount); ?>%</p>
				<button type="button" class="btn btn-danger"><a href="<?php echo e(route('user.details', [$product->id])); ?>">Buy Now</a></button>
				<p><b id="b"><?php echo e($product->product_name); ?></b></p>
				<p>Price:<?php echo e($product->product_price); ?></p>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<?php endif; ?>
		</div>
	</div>
	<div class="col-md-5 ml-auto">
			<div class="row">
				<div class="col-md-12">
					<div class="row">
						<div class="card cd col-md-3 ml-auto">
							<div class="card-header">
								<a href="<?php echo e(route('user.cartshow')); ?>"><img id="cart" src="<?php echo e(asset('images')); ?>/admin/order.png"></a>
								<p>Items:<?php echo e(Cart::count()); ?></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<div class="container c1">
		<div class="row">
			
		</div>
	</div>
	<div class="container c1">
		<div class="row">
			<p>Page:<?php echo e($products->links()); ?></p>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>