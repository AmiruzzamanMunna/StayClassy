<?php $__env->startSection('title'); ?>
	Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style9.css">
	<script src="<?php echo e(asset('js')); ?>/script2.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		function change() {
			var img=document.getElementById('td1');
			img.src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>";
		}
		function change1() {
			var img=document.getElementById('td1');
			img.src="<?php echo e(asset('images')); ?>/<?php echo e($product->image2); ?>";
		}
		function change2() {
			var img=document.getElementById('td1');
			img.src="<?php echo e(asset('images')); ?>/<?php echo e($product->image3); ?>";
		}

	</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="container-fluid">
		<div class="row ml-auto">
			<div class="col-md-12">
				<div class="row ml-auto">
					<div class="table col-md-4 dvtb ml-auto">
						<table class="table-bordered">
							<tr>
								<th>Product</th>
							</tr>
							<tr>
								<td><img id="td1" class="tbimg" src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" alt="td1"></td>
							</tr>
						</table>
					</div>
					<div class="col-md-5 m-auto cat">
						<div class="row">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-12">
										<form>
											<?php echo e(csrf_field()); ?>

											<?php
												$result=0;
											?>
											<div class="card crd">
													<h4 class="m-auto"><?php echo e($product->product_name); ?></h4>
												<div class="card-body">
													<input type="hidden" name="" id="add-cart-id" value="<?php echo e($product->id); ?>">
													<div class="form-group row">
														<label class="col-md-6">Category:</label>
														<label class="col-md-6"><?php echo e($product->category_name); ?></label>
													</div>
													<div class="form-group row">
														<label class="col-md-6">Type:</label>
														<label class="col-md-6"><?php echo e($product->type_name); ?></label>
													</div>
													<div class="form-group row">
														<label class="col-md-6">Available:
														</label>
														<label class="col-md-6">
															<?php if($product->product_quantity > 0): ?>
																In stock
															<?php else: ?>
																Out of stock
															<?php endif; ?>
														</label>
													</div>
													<div class="form-group row">
														<label class="col-md-6">Discount:</label>
														<label class="col-md-6"><?php echo e($product->discount); ?></label>
													</div>
													<div class="form-group row">
														<label class="col-md-6">Price:</label>
														<?php
														
															$result=$product->product_price-($product->discount*$product->product_price/100);
														?>
														<label class="col-md-6"><del><?php echo e($product->product_price); ?></del><?php echo e($result); ?>tk</label>
													</div>
													<div class="form-group row">
														<label class="col-md-6">Quantity:</label>
														<input type="text" id="add-cart-quantity" name="Quantity" value="1">
														<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<?php echo e($error); ?>

														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</div>
													<div class=" form-group row">
														<div class="col-md-12">
															<button type="button" id="add-cart-button" class="btn btn-success col-md-12">Add To Cart</button>
														</div>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="row m-auto">
					<div class="col-md-6 ml-auto">
						<div class="row m-auto">
							<div class="col-md-3 dvim">
								<img id="im1" class="simg" src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" alt="im1" onclick="change();">
							</div>
							<div class="col-md-3 dvim">
								<img id="#" class="simg" src="<?php echo e(asset('images')); ?>/<?php echo e($product->image2); ?>" onclick="change1();">
							</div>
							<div class="col-md-3 dvim">
								<img id="#" class="simg" src="<?php echo e(asset('images')); ?>/<?php echo e($product->image3); ?>" onclick="change2();">
							</div>
						</div>
					</div>
					<div class="col-md-5">
						<div class="row">
							<div class="col-md-12">
								<div class="row">
									<div class="card cd col-md-3">
										<div class="card-header">
											<a href="<?php echo e(route('user.cartshow')); ?>"><img id="cart" src="<?php echo e(asset('images')); ?>/admin/order.png"></a>
											<p id="item">Items:<?php echo e($cartItem); ?></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row m-auto">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-10 dvpd m-auto">
						<a href="">Details</a>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-10 m-auto">
								<div class="card col-md-6">
									<div class="card-body">
										<table class="table table-bordered table-md table-striped">
											<?php if($specifications): ?>
												<?php $__empty_1 = true; $__currentLoopData = $specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
												<tr>
													<td><?php echo e($specification); ?></td>
												</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
													aksrhfserhkf
												<?php endif; ?>
											<?php endif; ?>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>