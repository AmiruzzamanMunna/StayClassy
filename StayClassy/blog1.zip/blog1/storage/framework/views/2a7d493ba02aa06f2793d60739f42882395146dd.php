<?php $__env->startSection('title'); ?>
	Add New Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/addnew.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js')); ?>/jquery.validate.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/validation/script2.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-9 m-auto"><br><br><br>
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-12">
					<div class="card">
					<div class="card-header"><h2>Update Product</h2></div>
					<div class="card-body">
						<div class="row">
							<form action="" method="post" id="update-product-form" enctype="multipart/form-data">
								<?php echo e(csrf_field()); ?>

								<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Name:</label>
									<div class="col-md-8">
										<input type="text" class="form-control col-md-8" name="pname"
										value="<?php echo e($product->product_name); ?>">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Code:</label>
									<div class="col-md-8">
										<?php echo e($product->code); ?>

									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Sold Item:</label>
								<div class="col-md-8">
										<input type="number" class="form-control col-md-8" name="sold_item" value="<?php echo e($product->sold_item); ?>">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Buying Price:</label>
									<div class="col-md-8">
										<input type="number" class="form-control col-md-8" name="buyprice" value="<?php echo e($product->buy_price); ?>">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Price:</label>
									<div class="col-md-8">
										<input type="number" class="form-control col-md-8" name="price" value="<?php echo e($product->product_price); ?>">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Discount:</label>
									<div class="col-md-8">
										<input type="text" class="form-control col-md-8" name="discount" value="<?php echo e($product->discount); ?>">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Quantity:</label>
									<div class="col-md-8">
										<input type="number" class="form-control col-md-8" name="quantity" value="<?php echo e($product->product_quantity); ?>">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">New Arrival:</label>
									<div class="col-md-8">
										<label class="radio-inline">
											<input type="radio" name="new" value="1" checked>Yes
											<input type="radio" name="new" value="0">No
										</label>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Category:</label>
									<div class="col-md-8">
										<select class="form-control col-md-8" name="category">
											<?php $__empty_2 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
												<option value="<?php echo e($category->id); ?>">				<?php echo e($category->name); ?>

												</option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Type:</label>
									<div class="col-md-8">
										<select class="form-control col-md-8" name="type">
											<?php $__empty_2 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
												<option value="<?php echo e($type->id); ?>">
													<?php echo e($type->name); ?>

												</option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Image1:</label>
									<div class="col-md-8">
										<input type="file" class="form-control col-md-8" name="img1" id="img1">
										<img id="src1">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Image2:</label>
									<div class="col-md-8">
										<input type="file" class="form-control col-md-8" name="img2" id="img2">
										<img id="src2">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Image3:</label>
									<div class="col-md-8">
										<input type="file" class="form-control col-md-8" name="img3" id="img3">
										<img id="src3">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3 ml-auto">Status:</label>
									<div class="col-md-8">
										<label class="radio-inline">
											<input type="radio" name="status" value="5" checked>Active
											<input type="radio" name="status" value="6">Deactive
										</label>
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 ml-auto">Specification1:</label>
									<input type="text" name="specification[]" class="form-control col-md-7">
									<div class="col-md-8 ml-auto">
										<input type="button" class="btn btn-success" name="" id="bt1" value="Add New Field">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 ml-auto" id="th1">Specification2:</label>
									<input type="text" id="tx1" name="specification[]" class="form-control col-md-6">
									<div class="col-md-1">
										<input type="button" class="btn btn-danger" name="" id="bt2" value="Remove">
									</div>
									<div class="col-md-6">
										<input type="button" class="btn btn-success" name="" id="bt3" value="Add New Field">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 ml-auto" id="th2">Specification3:</label>
									<input type="text" id="tx2" name="specification[]" class="form-control col-md-6">
									<div class="col-md-1">
										<input type="button" class="btn btn-danger" name="" id="bt4" value="Remove">
									</div>
									<div class="col-md-6">
										<input type="button" class="btn btn-success" name="" id="bt5" value="Add New Field">
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
								<?php if($errors->any()): ?>
									<ul>
										<?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								<?php endif; ?>
								<div class="row">
									<div class="col-md-5">
										<input type="reset" class="btn btn-danger" name="" value="Reset">
									</div>
									<div class="col-md-3">
										<input type="submit" class="btn btn-success" name="" value="Save">
									</div>
									<div class="col-md-3">
										<button type="button" class="btn btn-warning"><a href="<?php echo e(route('product.delete',[$id])); ?>">Delete</a></button>
									</div>
									<?php if(session('message')): ?>
										<div class="alert alert-success m-auto">
											<?php echo e(session('message')); ?>

										</div>
									<?php endif; ?>
								</div>
							</form>
							<div class="col-md-3">
								<img class="image" src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>">
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>