<?php $__env->startSection('title'); ?>
	Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style9.css">
	<!-- <script src="<?php echo e(asset('js')); ?>/script2.js"></script> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="container-fluid">
		<div class="row ml-auto">
			<div class="col-md-12">
				<div class="row ml-auto">
					<div class="col-md-5 m-auto cat">
						<div class="row">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-12">
										<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<form method="post">
											<?php echo e(csrf_field()); ?>

											<div class="card crd">
													<h4 class="m-auto">Product Id:<?php echo e($cart->product_id); ?></h4>
												<div class="card-body">
													
													<div class="form-group row">
														<label class="col-md-6">Quantity:</label>
														<input type="text" name="Quantity" value="<?php echo e($cart->quantity); ?>">
														<?php if($errors->any()): ?>
															<ul class="m-auto">
																<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<li><?php echo e($error); ?></li>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															</ul>
														<?php endif; ?>
													</div>
													<div class=" form-group row">
														<div class="col-md-7 m-auto">
															<button type="submit" id="add-cart-button" class="btn btn-success col-md-8">Update Quantity</button>
														</div>
													</div>
												</div>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="col-md-5">
							<div class="row">
								<div class="col-md-12">
									<div class="row">
										<div class="card cd col-md-3">
											<div class="card-header">
												<a href="<?php echo e(route('user.cartshow')); ?>"><img id="cart" src="<?php echo e(asset('images')); ?>/admin/order.png"></a>
												<p id="item">Item:<?php echo e(Cart::count()); ?></p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>