<?php $__env->startSection('title'); ?>
	Add New Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script src="<?php echo e(asset('js')); ?>/script2.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-6 m-auto"><br><br><br>
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-10">
					<div class="card">
					<div class="card-header"><h2>Add New Product</h2></div>
					<div class="card-body">
					<form action="" method="post">
						<div class="form-group row">
							<label class="col-md-6">Name:</label>
							<input type="text" class="form-control col-md-6" name="name">
						</div>
						<div class="form-group row">
							<label class="col-md-6">Code:</label>
							<input type="number" class="form-control col-md-6" name="code">
						</div>
						<div class="form-group row">
							<label class="col-md-6">Buying Price:</label>
							<input type="number" class="form-control col-md-6" name="buyprice">
						</div>
						<div class="form-group row">
							<label class="col-md-6">Price:</label>
							<input type="number" class="form-control col-md-6" name="price">
						</div>
						<div class="form-group row">
							<label class="col-md-6">Discount:</label>
							<select class="form-control col-md-6" name="discount">
								<option>Discount %</option>
								<option>0%</option>
								<option>5%</option>
								<option>10%</option>
								<option>15%</option>
								<option>20%</option>
							</select>
						</div>
						<div class="form-group row">
							<label class="col-md-6">Quantity:</label>
							<input type="number" class="form-control col-md-6" name="price">
						</div>
						<div class="form-group row">
							<label class="col-md-6">New Arrival:</label>
							<label class="radio-inline">
								<input type="radio" name="new">Yes
								<input type="radio" name="new">No
							</label>
						</div>
						<div class="form-group row">
							<label class="col-md-6">Category:</label>
							<select class="form-control col-md-6" name="category">
								<option>Travelling</option>
								<option>Duffel</option>
								<option>Office</option>
								<option>Regular</option>
								<option>New Arrivals</option>
							</select>
						</div>
						<div class="form-group row">
							<label class="col-md-6">Type:</label>
							<select class="form-control col-md-6" name="type">
								<option>Ladis</option>
								<option>Gents</option>
							</select>
						</div>
						<div class="form-group row">
							<label class="col-md-6">Image1:</label>
							<input type="file" class="form-control col-md-6" name="img1">
						</div>
						<div class="form-group row">
							<label class="col-md-6">Image2:</label>
							<input type="file" class="form-control col-md-6" name="img2">
						</div>
						<div class="form-group row">
							<label class="col-md-6">Image3:</label>
							<input type="file" class="form-control col-md-6" name="img3">
						</div>
						<div class="form-group row">
							<label class="col-md-6">Status:</label>
							<label class="radio-inline">
								<input type="radio" name="status">Active
								<input type="radio" name="status">Deactive
							</label>
						</div>
						<div class="form-group row">
							<label class="col-md-5">Specification1:</label>
							<input type="text" name="">
							<input type="button" class="btn btn-success" name="" id="bt1" value="Add New Field">
						</div>
						<div class="form-group row">
							<label class="col-md-5" id="th1">Specification2:</label>
							<input type="text" id="tx1" name="">
							<div class="col-md-1">
								<input type="button" class="btn btn-danger" name="" id="bt2" value="Remove">
							</div>
							<input type="button" class="btn btn-success" name="" id="bt3" value="Add New Field">
						</div>
						<div class="form-group row">
							<label class="col-md-5" id="th2">Specification3:</label>
							<input type="text" id="tx2" name="">
							<div class="col-md-1">
								<input type="button" class="btn btn-danger" name="" id="bt4" value="Remove">
							</div>
							<input type="button" class="btn btn-success" name="" id="bt5" value="Add New Field">
						</div>
						<div class="row">
							<div class="col-md-8">
								<input type="reset" class="btn btn-danger" name="" value="Reset">
							</div>
							<div class="col-md-3">
								<input type="submit" class="btn btn-success" name="" value="Save">
							</div>
						</div>
					</form>
				</div>
				</div>
			</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>