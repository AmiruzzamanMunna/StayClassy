<?php $__env->startSection('title'); ?>
	User Profile
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/order.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-5 m-auto">
        <div class="card">
            <div class="card-header">User info</div>
            <div class="card-body">
                <div class="form-group row">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="col-md-6">Name</label>
                    <label class="col-md-6"><?php echo e($customer->name); ?></label>
                    <label class="col-md-6">Email</label>
                    <label class="col-md-6"><?php echo e($customer->email); ?></label>
                    <label class="col-md-6">Mobile1</label>
                    <label class="col-md-6"><?php echo e($customer->mobile1); ?></label>
                    <label class="col-md-6">Mobile2</label>
                    <label class="col-md-6"><?php echo e($customer->mobile2); ?></label>
                    <label class="col-md-6">Address</label>
                    <label class="col-md-6"><?php echo e($customer->address); ?></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                       <a href="<?php echo e(route('user.orderdetails',[$customer->invoice_id])); ?>" class="btn btn-primary">All Order</a>
                       <?php break; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="row">
                    <dir class="col-md-12">
                        <div class="row">
                            <div class="col-md-2 m-auto">
                              
                            </div>
                        </div>
                    </dir>
                </div>
            </div>
        </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>