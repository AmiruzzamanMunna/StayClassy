<?php $__env->startSection('title'); ?>
	Manage User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/stufflist.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8">
		
		<div class="card">
			<div class="row">
			<?php if(session('message')): ?>
				<div class="alert alert-success m-auto">
					<?php echo e(session('message')); ?>

				</div>
			<?php endif; ?>
		</div>
			<div class="card-header"><h2>Manage User</h2></div>
				<div class="card-body">
					<table class="table table-bordered table-md table-striped">
						<tr>
							<th>Id</th>
							<th>Name</th>
							<th>Username</th>
							<th>E-Mail</th>
							<th>Mobile1</th>
							<th>Mobile2</th>
							<th>Delete</th>
						</tr>
						<?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($admin->id); ?></td>
							<td><?php echo e($admin->name); ?></td>
							<td><?php echo e($admin->username); ?></td>
							<td><?php echo e($admin->email); ?></td>
							<td><?php echo e($admin->mobile1); ?></td>
							<td><?php echo e($admin->mobile2); ?></td>
							<td><a href="<?php echo e(route('admin.destroy',[$admin->id])); ?>">Delete</a></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>
					
					</table>
				</div>
			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>