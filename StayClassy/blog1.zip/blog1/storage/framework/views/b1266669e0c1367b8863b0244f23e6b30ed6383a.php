<?php $__env->startSection('title'); ?>
	User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/order.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8 m-auto">
		<div class="card">
			<div class="card-header">
				<h2>Customer info</h2>
			</div>
			<div class="card-body">
				<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="form-group row">
					<label class="col-md-6">Customer name: </label>
					<label class="col-md-6"><?php echo e($order->name); ?></label>
					<label class="col-md-6">Customer contact: </label>
					<label class="col-md-6"><?php echo e($order->mobile1); ?></label>
					<label class="col-md-6">Address: </label>
					<label class="col-md-6"><?php echo e($order->address); ?></label>
					<label class="col-md-6">Order date: </label>
					<label class="col-md-6"><?php echo e($order->date); ?></label>
					<label class="col-md-6">Status: </label>
					<label class="col-md-6"><?php echo e($order->status_name); ?></label>
				</div>
				<?php break; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</div>
		</div>
		<div class="card">
			<div class="card-header"><h2>All Order</h2></div>
			<div class="card-body">
				<table class="table table-bordered table-md table-striped">
					<tr>
						<th>Image</th>
						<th>Product Name</th>
						<th>Product Code</th>
						<th>Quantity</th>
						<th>Price</th>
						<th>Status</th>
					</tr>
					<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td><img src="<?php echo e(asset('images')); ?>/<?php echo e($order->image1); ?>" id="img"></td>
						<td><?php echo e($order->product_name); ?></td>
						<td><?php echo e($order->code); ?></td>
						<td><?php echo e($order->quantity); ?></td>
						<td><?php echo e($order->totalprice); ?></td>
						<td><?php echo e($order->status_name); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<?php endif; ?>
				</table>
			</div>
			<div class="card-footer">
				</div>
				<div class="row">
					<dir class="col-md-12">
						<div class="row">
							<div class="col-md-2 m-auto">
								<?php echo e($orders->links()); ?>

							</div>
						</div>
					</dir>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>