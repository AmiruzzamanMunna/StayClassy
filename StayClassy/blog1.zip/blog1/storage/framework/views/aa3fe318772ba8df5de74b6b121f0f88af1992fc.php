<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/login.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/bootstrap.min.css">

	<script src="<?php echo e(asset('js')); ?>/jquery.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/popper.min.js">
 	</script>
	<script src="<?php echo e(asset('js')); ?>/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="<?php echo e(asset('js')); ?>/jquery.validate.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/script1.js"></script>

</head>
<body>
<div class="row">
	<div class="col-md-12">
		<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
			<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsenav">
			<span class="navbar-toggler-icon"></span>
			</button>
			<h1 class="h m-auto">Admin Panel</h1>
			<div class="col-md-1">
				<ul class="navbar-nav">
					
				</ul>
			</div>
			<div class="col-md-1">
				<!-- <ul class="navbar-nav">
					<li class="nav-item">
						<a href="#" class="nav-link">Logout</a>
					</li>
				</ul> -->
			</div>
		</nav>
	</div>
</div>
<div class="col-md-6 m-auto">
		<div class="row"></div>
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-10">
						<div class="card">
							<?php if(session('message')): ?>
								<div class="alert alert-success m-auto">
									<?php echo e(session('message')); ?>

								</div>
							<?php endif; ?>
						<div class="card-header"><h2>Admin Login</h2></div>
						<div class="card-body">
							<form action="" method="POST" id="Admin">
								<?php echo e(csrf_field()); ?>

								<div class="form-group row">
									<label class="col-md-3">User Name:</label>
									<div class="col-md-6">
										<input type="text" class="form-control" name="Username">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3">Password:</label>
									<div class="col-md-6">
										<input type="Password" class="form-control" name="Password">
									</div>
								</div>
								<?php if($errors->any()): ?>
									<ul>
										<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								<?php endif; ?>
								<div class="row">
									<div class="col-md-8">
										<input type="reset" class="btn btn-danger" name="" value="Reset">
									</div>
									<div class="col-md-3">
										<input type="submit" class="btn btn-success" name="" value="Login">
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
