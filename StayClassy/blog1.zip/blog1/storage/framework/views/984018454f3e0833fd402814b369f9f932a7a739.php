<?php $__env->startSection('title'); ?>
    Stay Classy
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style11.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <div class="row">
            <div id="demo" class="carousel slide carudemo" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                </ul>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img class="caruimg" src="images/banner-1.jpg" alt="mm">
                    </div>
                    <div class="carousel-item">
                        <img class="caruimg" src="images/banner-1.jpg" alt="mm1">
                    </div>
                    <div class="carousel-item">
                        <img class="caruimg" src="images/banner-1.jpg" alt="mm2">
                    </div>
                </div>
                <a href="#demo" class="carousel-control-prev" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                </a>
                <a href="#demo" class="carousel-control-next" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
                <a href="#demo" class="carousel-control-next" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>
    </div>
    <br>
    <div class="container">
        <h1>Stay Classy Essential</h1><br>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" class="rounded-circle rcc" alt="logo">
                <p id="discount"><?php echo e($product->discount); ?>%</p>
                <button type="button" class="btn btn-danger"><a href="<?php echo e(route('user.details', [$product->id])); ?>">Buy Now</a></button>
                <p><b id="b"><?php echo e($product->product_name); ?></b></p>
                <p>Price:<?php echo e($product->product_price); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
        <div class="col-md-5 ml-auto">
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="card cd col-md-3 ml-auto">
                            <div class="card-header">
                                <a href="<?php echo e(route('user.cartshow')); ?>"><img id="cart" src="<?php echo e(asset('images')); ?>/admin/order.png"></a>
                                <?php echo e(Cart::count()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="container">
            <div class="row">
                <div class="col-md-2">
                    <p id="pp">StayClassy is a Online Shop</p>
                    <div class="row">
                        <div class="col-md-4">
                            <img class="rcc2" src="images/banner-2.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <img class="rcc2" src="images/speech-2.jpg">
                </div>
            </div>
        </div>
        <br>
        
    <div class="container">
        <h2>Popular Items</h2><br>
        <!-- <div class="row"> -->
            <!-- 
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-2.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name B</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-3.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name C</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-4.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name F</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-5.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name E</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-6.jpg" class="rounded-circle" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name D</b></p>
                <p>Price:1000tk</p>
            </div> -->
        <!-- </div> -->
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="<?php echo e(route('user.details', [$product->id])); ?>">Buy Now</a></button>
                <p><b id="b"><?php echo e($product->product_name); ?></b></p>
                <p>Price:<?php echo e($product->product_price); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
        </div>
    </div>
    <br>
    <div class="container">
            <h3>New Arrivals</h3><br>
        <!-- <div class="row" id="na">
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-2.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name B</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-3.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name C</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-4.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name F</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-5.jpg" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name E</b></p>
                <p>Price:1000tk</p>
            </div>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="images/bag/bag-6.jpg" class="rounded-circle" alt="logo">
                <button type="button" class="btn btn-danger"><a href="#">Buy Now</a></button>
                <p><b id="b">Name D</b></p>
                <p>Price:1000tk</p>
            </div>
        </div> -->
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 col-lg-2 col-sm-4 col-xl-2">
                <img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" class="rounded-circle rcc" alt="logo">
                <button type="button" class="btn btn-danger"><a href="<?php echo e(route('user.details', [$product->id])); ?>">Buy Now</a></button>
                <p><b id="b"><?php echo e($product->product_name); ?></b></p>
                <p>Price:<?php echo e($product->product_price); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div><br><br><br><br><br><br>
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-12">
                <h3>Follow Us</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 m-auto">
                <div class="row">
                    <div class="col-md-3">
                        <a href="<?php echo e($social->facebook); ?>">
                        <img src="images/fb.png" class="rounded-circle rc1" alt="logo">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="<?php echo e($social->youtube); ?>">
                            <img src="images/youtube.png" class="rounded-circle rc1" alt="logo1">
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="<?php echo e($social->instagram); ?>">
                            <img src="images/insta.png" class="rounded-circle rc1" alt="logo2" >
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="<?php echo e($social->twitter); ?>">
                            <img src="images/twitter.png" class="rounded-circle rc1" alt="logo3">
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>