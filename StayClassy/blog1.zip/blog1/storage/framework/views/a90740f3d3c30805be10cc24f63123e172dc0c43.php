;
<?php $__env->startSection('title'); ?>
	Footer
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="container footer-container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-8">
						<?php $__currentLoopData = $qualitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<h1><?php echo e($quality->heading); ?></h1>
							<p><?php echo e($quality->title); ?></p>
							<p><?php echo e($quality->description); ?></p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>