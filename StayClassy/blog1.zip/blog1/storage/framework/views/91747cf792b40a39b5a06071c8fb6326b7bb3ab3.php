<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;    
}
</style>
</head>
<body>
	<h1>Stay Classy</h1>
	<table class="table table-bordered table-striped" style="width: 100%">
		<tr>
			<th>Date</th>
			<th>Amount</th>
			<th>Role</th>
			</th>
		</tr>
			<?php $__empty_1 = true; $__currentLoopData = $transetions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transetion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<td><?php echo e($transetion->date); ?></td>
				<td><?php echo e($transetion->amount); ?></td>
				<td>
					<?php if($transetion->role == 0): ?>
						Invest
					<?php else: ?>
						Income
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<?php endif; ?>
			<tr>
				<td>Total</td>
				<td>Invest=<?php echo e($invest); ?></td>
				<td>Income=<?php echo e($income); ?></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td>
					<?php if($profit == 0): ?>
					Loss = <?php echo e($loss); ?>

					<?php else: ?>
					Profit = <?php echo e($profit); ?>

					<?php endif; ?>
				</td>
			</tr>
	</table>
</body>
</html>