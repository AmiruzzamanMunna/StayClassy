<?php $__env->startSection('title'); ?>
	Stuff List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8 m-auto">
		<div class="card">
			<div class="card-header"><h2>Stuff List</h2></div>
				<div class="card-body">
					<table class="table table-bordered table-md table-striped">
						<tr>
							<th>Name</th>
							<th>Username</th>
							<th>Phone</th>
							<th>E-Mail</th>
						</tr>
						<tr>
							<td>Munna</td>
							<td>Amiruzzaman</td>
							<td>01641064684</td>
							<td>munna.ak17@gmail.com</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>