<?php $__env->startSection('title'); ?>
	Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script src="<?php echo e(asset('js')); ?>/filter.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-7"><br>
		<div class="row">
			<div class="card">
				<div class="card-header">
					<h2>All Products</h2>
				</div>
				<div class="card-body">
					<table class="table table-bordered table-striped" id="product-list">
						<tr>
							<th>Image</th>
							<th>Name</th>
							<th>Code</th>
							<th>Category</th>
							<th>Type</th>
							<th>Buy Price</th>
							<th>Price</th>
							<th>Discount %</th>
							<th>Quantity</th>
						</tr>
						<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" class="ig"></td>
							<td><a href="<?php echo e(route('product.productedit',[$product->id])); ?>"><?php echo e($product->product_name); ?></a></td>
							<td><?php echo e($product->code); ?></td>
							<td><?php echo e($product->category_name); ?></td>
							<td><?php echo e($product->type_name); ?></td>
							<td><?php echo e($product->buy_price); ?></td>
							<td><?php echo e($product->product_price); ?></td>
							<td><?php echo e($product->discount); ?></td>
							<td><?php echo e($product->product_quantity); ?><br>
								<a href="<?php echo e(route('Product.quantity',[$product->id])); ?>">Add</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>
					</table>
				</div>
				<div class="card-footer">
					<div class="row">
						<dir class="col-md-12">
							<div class="row">
								<div class="col-md-2 m-auto">
									<?php echo e($products->links()); ?>

								</div>
							</div>
						</dir>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-2"><br>
		<div class="row m-auto">
			<div class="card">
				<div class="card-header">
					<h3>Categories</h3>
				</div>
				<div class="card-body">
					<form action="" method="get">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="form-group row">
							<label class="cat">
								<input type="checkbox" class="categories" value="<?php echo e($category->id); ?>" name="categories[]" ><?php echo e($category->name); ?>

							</label>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</form>
				</div>
			</div>
		</div><br>
		<div class="row m-auto">
			<div class="card">
				<div class="card-header">
					<h4> Category Types</h4>
				</div>
				<div class="card-body">
					<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="form-group type row">
							<label class="">
								<input type="checkbox" class="type" name="categories_types" value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?>

							</label>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>