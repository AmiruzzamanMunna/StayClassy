<?php $__env->startSection('title'); ?>
	Search Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style11.css">
<?php $__env->stopSection(); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
		<div class="row">
			<div class="col-md-10">
				<div class="row">
					<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<?php if($product): ?>
						<div class="col-md-3 col-lg-2 col-sm-4 col-xl-2"><br><br><br><br>
						<img src="<?php echo e(asset('images')); ?>/<?php echo e($product->image1); ?>" class="rounded-circle rcc" alt="logo">
						<p><?php echo e($product->discount); ?></p>
						<button type="button" class="btn btn-danger"><a href="<?php echo e(route('user.details', [$product->id])); ?>">Buy Now</a></button>
						<p><b id="b"><?php echo e($product->product_name); ?></b></p>
						<p>Price:<?php echo e($product->product_price); ?></p>
						</div>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="row m-auto">
							<div class="col-md-12 m-auto">
								<div class="row m-auto">
									<div class="col-md-12"><br><br><br><br><br><br><br><br>
										<h1 style="color: red">Sorry Product is not Available</h1>
									</div>
								</div>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
	</div>
</div>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>