<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('css')); ?>/font-awesome.min.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
	<script src="<?php echo e(asset('js')); ?>/jquery.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/popper.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/bootstrap.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/script.js"></script>
	<script src="<?php echo e(asset('js')); ?>/ajax.js"></script>
	<?php echo $__env->yieldContent('css'); ?>
	<?php echo $__env->yieldContent('script'); ?>
</head>
<body>
	<div class="container-fluid">
		<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
			<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#myCollapse">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="myCollapse">
				<ul class="m-auto navbar-nav">
					<li class="nav-item"> 
						<a href="<?php echo e(route('user.category','Travelling')); ?>" class="nav-link" id="nvlk">Travelling</a>
					</li>
					<li class="nav-item">
						<a href="" class="nav-link" id="nvlk" >Duffel</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.category','Office')); ?>" class="nav-link" id="nvlk">Office</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.category','Regular')); ?>" class="nav-link" id="nvlk">Regular</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.category','Other')); ?>" class="nav-link" id="nvlk">Other Bags</a>
					</li>
			 	</ul>
				<a href="<?php echo e(route('user.index')); ?>" class="navbar-brand">Stay Classy</a>
				<ul class="ml-auto navbar-nav">
					<li class="nav-item">
						<a href="<?php echo e(route('user.newarrival')); ?>" class="nav-link" id="nvlk">New Arrivals</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.type','Gents')); ?>" class="nav-link" id="nvlk">Gents</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.type','Ladies')); ?>" class="nav-link" id="nvlk">Ladies</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.offers')); ?>" class="nav-link" id="nvlk">Offers</a>
					</li>
					<?php if(Session::has('loggedUser')): ?>
					<li class="nav-item ">
						<a href="#" class="nav-link" id="nvlk">Account</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.logout')); ?>" class="nav-link" id="nvlk">Logout</a>
					</li>
					<?php else: ?>
					<li class="nav-item ">
						<a href="<?php echo e(route('user.sign')); ?>" class="nav-link" id="nvlk">Sign-Up</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.userlogin')); ?>" class="nav-link" id="nvlk">Log-in</a>
					</li>
					<?php endif; ?>
					<!-- <i class="fa fa-search m-auto" id="icon"> -->
						<li class="nav-item col-md-4 m-auto" id="list">
							<input type="search" placeholder="search" name="searchbox">
						<!-- <input type="submit" class="btn btn-primary" name="" value="Search"> -->
						</li>
					<!-- </i> -->
					
				</ul>
			</div>
		</nav>
	</div>
	<?php echo $__env->yieldContent('container'); ?>
	<div class="container-fluid" id="footer">
		<footer>
			<div class="row">
				<div class="col-md-12">
					<div class="row">	
						<div class="col-md-8 m-auto">
							<div class="row">
								<div class="col-md-4 content">
									<?php $__empty_1 = true; $__currentLoopData = $qualitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<h5><?php echo e($quality->heading); ?></h5>
									<p><?php echo e($quality->title); ?></p>
									<p><?php echo e($quality->description); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
								<div class="col-md-4 content">
									<?php $__empty_1 = true; $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<h5><?php echo e($return->heading); ?></h5>
									<p><?php echo e($return->title); ?></p>
									<p><?php echo e($return->description); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
								<div class="col-md-4 content">
									<?php $__empty_1 = true; $__currentLoopData = $shippings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<h5><?php echo e($shipping->heading); ?></h5>
									<p><?php echo e($shipping->title); ?></p>
									<p><?php echo e($shipping->description); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>	
							</div>
						</div>
					</div>
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-7 m-auto content">
							<div class="row">
								<div class="col-md-3 content">
									<?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<h6><?php echo e($customer->heading); ?></h6>
									<p><?php echo e($customer->title); ?></p>
									<p><?php echo e($customer->description); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
								<div class="col-md-3 content">
									<?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<h6><?php echo e($contact->heading); ?></h6>
									<p><?php echo e($contact->contactnumber); ?></p>
									<p><?php echo e($contact->email); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
								<div class="col-md-3 content">
									<?php $__empty_1 = true; $__currentLoopData = $policys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<h6><?php echo e($policy->heading); ?></h6>
									<p><?php echo e($policy->title); ?></p>
									<p><?php echo e($policy->description); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
								<div class="col-md-3 content">
									<?php $__empty_1 = true; $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<h6><?php echo e($about->heading); ?></h6>
									<p><?php echo e($about->title); ?></p>
									<p><?php echo e($about->description); ?></p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>
</body>
</html>
