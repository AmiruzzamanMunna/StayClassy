<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="card">
		<div class="card-header">Order Information</div>
		<div class="card-body">
			<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="form-group row">
				<label class="col-md-6">Name:</label>
				<label class="col-md-6"><?php echo e($user->name); ?></label>
			</div>
			<div class="form-group row">
				<label class="col-md-6">Address:</label>
				<label class="col-md-6"><?php echo e($user->address); ?></label>
			</div>
			<div class="form-group row">
				<label class="col-md-6">E-Mail:</label>
				<label class="col-md-6"><?php echo e($user->email); ?></label>
				<?php break; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</div>
			<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="form-group row">
				<label class="col-md-6">Order No:</label>
				<label class="col-md-6"><?php echo e($user->id); ?></label>
			</div>
			<div class="form-group row">
				<label class="col-md-6">Product Code</label>
				<label class="col-md-6"><?php echo e($user->code); ?></label>
			</div>
			<div class="form-group row">
				<label class="col-md-6">Product Name</label>
				<label class="col-md-6"><?php echo e($user->product_name); ?></label>
			</div>
			<div class="form-group row">
				<label class="col-md-6">Subtotal Price</label>
				<label class="col-md-6"><?php echo e($user->totalprice); ?></label>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<?php endif; ?>
			<div class="form-group row">
				<label class="col-md-6">Total Price</label>
				<label class="col-md-6"><?php echo e($total); ?></label>
			</div>
			<div class="form-group row">
				<label class="col-md-6">Order Date</label>
				<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<label class="col-md-6"><?php echo e($user->date); ?></label>
				<?php break; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</div>
		</div>
		<div class="card-footer">Thank You for Ordering</div>
	</div>
</body>
</html>