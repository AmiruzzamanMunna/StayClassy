<?php $__env->startSection('title'); ?>
	Update Stuff
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/stufflist.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8">
		<div class="card">
			<div class="card-header">Update Profile</div>
			<div class="card-body">
				<?php $__empty_1 = true; $__currentLoopData = $stuffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stuff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<form action="" name="" method="POST">
					<?php echo e(csrf_field()); ?>

					<div class="form-group row">
					</div>
					<div class="form-group row">
						<label class="col-md-4">Name:</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="name" value="<?php echo e($stuff->name); ?>">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-4">Username:</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="username" value="<?php echo e($stuff->username); ?>" disabled>
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-4">Phone:</label>
						<div class="col-md-6">
							<input type="text" class="form-control" name="phone" value="<?php echo e($stuff->phone); ?>">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-4">Email:</label>
						<div class="col-md-6">
							<input type="email" class="form-control" name="email" value="<?php echo e($stuff->email); ?>">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-4">Password:</label>
						<div class="col-md-6">
							<input type="password" class="form-control" name="password" value="<?php echo e($stuff->password); ?>">
						</div>
					</div>
					<div class="form-group row">
						<label class="col-md-4">Confirm Password:</label>
						<div class="col-md-6">
							<input type="password" class="form-control" name="confirm_password" value="<?php echo e($stuff->confirm_password); ?>">
						</div>
					</div>
					<div class="row">
						<div class="col-md-3 ml-auto">
							<input type="submit" class="btn btn-success" name="" value="Update">
						</div>
					</div>
				</form>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			</div>
			<div class="card-footer">
				<div class="col-md-6 m-auto">
					<?php if(session('message')): ?>
					<div class="alert alert-success m-auto">
						<?php echo e(session('message')); ?>

					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>