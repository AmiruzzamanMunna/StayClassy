<?php $__env->startSection('title'); ?>
	Stuff List
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/stufflist.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8">
		
		<div class="card">
			<div class="row">
			<?php if(session('message')): ?>
				<div class="alert alert-success m-auto">
					<?php echo e(session('message')); ?>

				</div>
			<?php endif; ?>
		</div>
			<div class="card-header"><h2>Stuff List</h2></div>
				<div class="card-body">
					<table class="table table-bordered table-md table-striped">
						<tr>
							<th>Id</th>
							<th>Name</th>
							<th>Username</th>
							<th>Phone</th>
							<th>E-Mail</th>
							<th>Delete</th>
						</tr>
						<?php $__empty_1 = true; $__currentLoopData = $stuffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stuff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($stuff->id); ?></td>
							<td><?php echo e($stuff->name); ?></td>
							<td><?php echo e($stuff->username); ?></td>
							<td><?php echo e($stuff->phone); ?></td>
							<td><?php echo e($stuff->email); ?></td>
							<td><a href="<?php echo e(route('stuff.destroy',[$stuff->id])); ?>">Delete</a></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>
					
					</table>
				</div>
			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>