<?php $__env->startSection('title'); ?>
	Social
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8"><br><br><br><br>
		<form action="" method="post">
			<div class="card">
				<div class="card-header"><h2>Social</h2></div>
				<div class="card-body">
					<?php echo e(csrf_field()); ?>

					<div class="form-group row">
						<?php $__empty_1 = true; $__currentLoopData = $social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<label class="col-md-4">FaceBook:</label>
						<input type="text" class="form-control col-md-6" name="facebook">
					</div>
					<div class="form-group row">
						<label class="col-md-4">Twitter:</label>
						<input type="text" class="form-control col-md-6" name="twitter">
					</div>
					<div class="form-group row">
						<label class="col-md-4">Instagram:</label>
						<input type="text" class="form-control col-md-6" name="instagram">
					</div>
					<div class="form-group row">
						<label class="col-md-4">Youtube:</label>
						<input type="text" class="form-control col-md-6" name="youtube">
						</div>
					<div class="row">
						<div class="col-md-3">
							<button type="button" class="btn btn-primary" name="" value=><a style="color: white" href="<?php echo e(route('footer.edit',[$social->id])); ?>">Edit</a></button>
						</div>
						<div class="col-md-3 ml-auto">
							<input type="submit" class="btn btn-success" name="" value="Save">
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<?php endif; ?>
					</div>
					<div class="col-md-6 m-auto">
						<?php if(session('message')): ?>
						<div class="alert alert-success m-auto">
							<?php echo e(session('message')); ?>

						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>