;
<?php $__env->startSection('title'); ?>
	Cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/cart.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="row">
        <div class="col-md-12">
            <div class="row">
            	<div class="col-md-7 m-auto">
            		<div class="card">
            			<form method="POST">
            				<?php echo e(csrf_field()); ?>

			            	<div class="card-header">Cart</div>
			            	<div class="card-body">
			            		<table class="table table-bordered table-striped table-hover">
				                    <tr>
				                        <th>User id</th>
				                        <th>Product Id</th>
				                        <th>Quantity</th>
				                        <th>Unit Price</th>
				                        <th>Subtotal</th>
				                        <th>Remove</th>
				                        <th>Update</th>
				                    </tr>
				                    <?php
				                    	$total=0;
				                    	$Subtotal=0;
				                    ?>
				                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                    <tr>
				                    	<td><?php echo e($cart->user_id); ?></td>
				                    	<td><?php echo e($cart->product_id); ?></td>
				                    	<td><?php echo e($cart->quantity); ?></td>
				                    	<td><?php echo e($cart->unit_price); ?></td>
				                    	<?php

				                    		$Subtotal=$cart->quantity*$cart->unit_price;
				                    		$total=$total+$Subtotal;
				                    	?>
				                    	<td><?php echo e($Subtotal); ?></td>
				                    	<td><a href="<?php echo e(route('user.cartremove',[$cart->id])); ?>">Remove</a></td>
				                    	<td><a href="<?php echo e(route('user.cartedit',[$cart->id])); ?>">Update</a></td>
				                    </tr>
				                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		           			 	</table>
		           			 	<div class="row">
		           			 		<div class="col-md-12">
		           			 			<div class="row">
		           			 				<div class="col-md-9 ml-auto">
		           			 					<label class="pull-right">Total Price:<?php echo e($total); ?></label>
		           			 				</div>
		           			 			</div>
		           			 		</div>
		           			 	</div>
	            			</div>
	            			<div class="card-footer">
	            				<div class="row">
	            					<div class="col-md-9">
	            					<button type="button" class="btn btn-default"><a href="<?php echo e(route('user.index')); ?>">Go Shopping</a></button>
	            				</div>
	            				<div class="col-md-2 ml-auto">
	            					<button type="submit" class="btn btn-basic">Order</button>
	            				</div>
	            			</div>
	            		</form>
           			 </div>
            	</div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.User-Home", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>