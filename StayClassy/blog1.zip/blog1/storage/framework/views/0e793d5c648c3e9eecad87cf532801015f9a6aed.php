<?php $__env->startSection('title'); ?>
	Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
	<div class="col-md-6 m-auto"><br><br><br><br><br>
		<div class="row"></div>
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-10">
						<div class="card">
							<?php if(session('message')): ?>
								<div class="alert alert-success m-auto">
									<?php echo e(session('message')); ?>

								</div>
							<?php endif; ?>
						<div class="card-header"><h2>User Login</h2></div>
						<div class="card-body">
							<form method="post" id="User">
								<?php echo e(csrf_field()); ?>

								<div class="form-group row">
									<label class="col-md-3">User Name:</label>
									<div class="col-md-6">
										<input type="text" class="form-control" name="username">
									</div>
								</div>
								<div class="form-group row">
									<label class="col-md-3">Password:</label>
									<div class="col-md-6">
										<input type="password" class="form-control" name="password">
									</div>
								</div>
								<!-- <div class="form-group row">
									<label class="col-md-8"><a href="<?php echo e(route('Mail.index')); ?>">Forgot Password?</a></label>
								</div> -->
								<?php if($errors->any()): ?>
									<ul>
										<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><?php echo e($error); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								<?php endif; ?>
								<div class="row">
									<div class="col-md-8">
										<input type="reset" class="btn btn-danger" name="" value="Reset">
									</div>
									<div class="col-md-3">
										<input type="submit" class="btn btn-success" name="" value="Login">
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.User-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>