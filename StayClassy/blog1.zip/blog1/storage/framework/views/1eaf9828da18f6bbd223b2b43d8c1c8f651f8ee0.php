<?php $__env->startSection('title'); ?>
	Add Stuff
<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>
	<div class="col-md-8"><br><br>
		<form action="" method="post">
			<div class="card">
				<div class="card-header"><h2>New Member</h2></div>
				<div class="card-body">
						<div class="form-group row">
							<label class="col-md-4">Name:</label>
							<input type="text" class="form-control col-md-6" name="name">
						</div>
						<div class="form-group row">
							<label class="col-md-4">User Name:</label>
							<input type="text" class="form-control col-md-6" name="usrname">
						</div>
						<div class="form-group row">
							<label class="col-md-4">Phone:</label>
							<input type="number" class="form-control col-md-6" name="phn">
						</div>
						<div class="form-group row">
							<label class="col-md-4">Email:</label>
							<input type="email" class="form-control col-md-6" name="email">
						</div>
						<div class="form-group row">
							<label class="col-md-4">Password:</label>
							<input type="password" class="form-control col-md-6" name="pas">
						</div>
						<div class="form-group row">
							<label class="col-md-4">Confirm Pasword:</label>
							<input type="password" class="form-control col-md-6" name="pas">
						</div>
						<div class="row">
							<div class="col-md-9">
								<input type="reset" class="btn btn-danger" name="" value="Reset">
							</div>
						<div class="col-md-3">
							<input type="submit" class="btn btn-success" name="" value="Confirm">
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin-Home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>