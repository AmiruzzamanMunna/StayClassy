<!DOCTYPE html>
<html>
<head>
	<title>User Signup</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/signup.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css')); ?>/bootstrap.min.css">

	<script src="<?php echo e(asset('js')); ?>/jquery.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/popper.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/jquery.validate.min.js"></script>
	<script src="<?php echo e(asset('js')); ?>/validation/script4.js"></script>
</head>
<body>
	<div class="row">
	<div class="col-md-12">
		<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
			<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#myCollapse">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="myCollapse">
				<ul class="m-auto navbar-nav">
					<li class="nav-item"> 
						<a href="<?php echo e(route('user.category','Travelling')); ?>" class="nav-link" id="nvlk">Travelling</a>
					</li>
					<li class="nav-item">
						<a href="" class="nav-link" id="nvlk" >Duffel</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.category','Office')); ?>" class="nav-link" id="nvlk">Office</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.category','Regular')); ?>" class="nav-link" id="nvlk">Regular</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.category','Other')); ?>" class="nav-link" id="nvlk">Other Bags</a>
					</li>
			 	</ul>
				<a href="<?php echo e(route('user.index')); ?>" class="navbar-brand">Stay Classy</a>
				<ul class="ml-auto navbar-nav">
					<li class="nav-item">
						<a href="<?php echo e(route('user.newarrival')); ?>" class="nav-link" id="nvlk">New Arrivals</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.type','Gents')); ?>" class="nav-link" id="nvlk">Gents</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.type','Ladies')); ?>" class="nav-link" id="nvlk">Ladies</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.offers')); ?>" class="nav-link" id="nvlk">Offers</a>
					</li>
					<li class="nav-item ">
						<a href="<?php echo e(route('user.sign')); ?>" class="nav-link" id="nvlk">Sign-Up</a>
					</li>
					<li class="nav-item">
						<a href="<?php echo e(route('user.userlogin')); ?>" class="nav-link" id="nvlk">Log-in</a>
					</li>
					<!-- <i class="fa fa-search m-auto" id="icon"> -->
						<li class="nav-item col-md-4 m-auto" id="list">
							<input type="search" placeholder="search" name="searchbox">
						<!-- <input type="submit" class="btn btn-primary" name="" value="Search"> -->
						</li>
					<!-- </i> -->
					
				</ul>
			</div>
		</nav>
	</div>
</div>
<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-8 m-auto">
						<div class="card">
							<div class="card-header">User Registration</div>
							<div class="card-body">
								<form id="userregistration" method="post">
									<?php echo e(csrf_field()); ?>

									<div class="form-group row">
										<label class="col-md-4">Name:</label>
										<div class="col-md-8">
											<input type="text" name="name" class="form-control">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4">User Name:</label>
										<div class="col-md-8">
											<input type="text" name="username" class="form-control">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4">E-mail:</label>
										<div class="col-md-8">
											<input type="email" name="email" class="form-control">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4">Mobile1:</label>
										<div class="col-md-8">
											<input type="text" name="mobile1" class="form-control">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4">Mobile2:</label>
										<div class="col-md-8">
											<input type="text" name="mobile2" class="form-control">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4">Address:</label>
										<div class="col-md-8">
											<input type="text" name="address" class="form-control">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4">Password:</label>
										<div class="col-md-8">
											<input type="password" name="password" class="form-control">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4">Confirm Password:</label>
										<div class="col-md-8">
											<input type="password" name="confirm_password" class="form-control">
										</div>
									</div>
									<?php if($errors->any()): ?>
										<ul>
											<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li><?php echo e($error); ?></li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									<?php endif; ?>
									<div class="row">
										<div class="col-md-9">
											<input type="reset" class="btn btn-primary" name="reset" value="Reset">
										</div>
										<div class="col-md-3 ml-auto">
											<input type="submit" class="btn btn-success" name="submit" value="Register">
										</div>
										<?php if(session('message')): ?>
											<div class="alert alert-success m-auto">
												<?php echo e(session('message')); ?>

											</div>
										<?php endif; ?>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
